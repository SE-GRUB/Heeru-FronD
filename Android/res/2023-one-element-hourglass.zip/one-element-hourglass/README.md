# One-Element Hourglass ⏳

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/wvWXyKG](https://codepen.io/jkantner/pen/wvWXyKG).

A hourglass preloader created using only one element. `clip-path` is the key property here.